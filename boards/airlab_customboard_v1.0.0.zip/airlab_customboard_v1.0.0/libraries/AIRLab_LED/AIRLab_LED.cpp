#include "AIRLab_LED.h"

void AIRLab_LED_Blink_Init(void)
{
  pinMode(13, OUTPUT);
}

void AIRLab_LED_Blink_Start(void)
{
  digitalWrite(13, HIGH);
  delay(500);
  digitalWrite(13, LOW);
  delay(500);
}
