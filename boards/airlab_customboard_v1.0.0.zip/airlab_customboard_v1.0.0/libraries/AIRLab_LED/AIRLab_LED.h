#include "Arduino.h"

void AIRLab_LED_Blink_Init(void);
void AIRLab_LED_Blink_Start(void);
